const mongodb = require('mongodb');
const mongoClient = mongodb.MongoClient;

let database;

async function getDataBase() {
    if (database) {
        return database; 
    }

    const client = await mongoClient.connect('mongodb://127.0.0.1:27017');
    database = client.db('BookedDemo'); 

    return database;
}

module.exports = { getDataBase };
