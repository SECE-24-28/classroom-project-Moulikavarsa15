const express = require('express')
const app = express()
const bodyParser = require('body-parser')   
const exhbs = require('express-handlebars')
const dbo = require('./db')

let message = "Mouli"
app.engine(
    'hbs',
    exhbs.engine({
        layoutsDir: 'viewsfound',
        defaultLayout: 'main',
        extname: 'hbs'
    })
)

app.set('view engine', 'hbs')
app.set('views', 'viewsfound')
app.use(bodyParser.urlencoded({
    extended: true
}))

app.post('/store_book',async(req,res)=>{
    let database = await dbo.getDataBase();
    const collection = database.collection('BookedDemo');
    let bookData={title:req.body.title,author:req.body.author}
    await collection.insertOne(bookData)
    return res.redirect('/?status=1')
})


app.get('/', async (req, res) => {
    let database = await dbo.getDataBase();
    const collection = database.collection('BookedDemo');
    const books = await collection.find({})
    let mydata = await books.toArray()
    switch (req.query.status) {
        case '1':
            message = "Book added successfully"
            break;
        default:
            break;
    }

    res.render('main', {
        message,
        mydata
    });
});

app.listen(8000, () => {
    console.log("Server is running on port 8000");
});



